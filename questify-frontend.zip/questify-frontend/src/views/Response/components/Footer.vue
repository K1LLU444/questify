<template>
  <v-footer color="transparent" class="text-white mt-5 text-center d-flex justify-center font-weight-medium">
    <div>
      <p>Thank you for choosing our service. Your satisfaction is important to us.</p>
      <p>We would greatly appreciate your feedback to help us serve you better in the future.</p>
      <div class="mt-5">
        <h1 class="text-center text-white mt-10 font-weight-bold" style="font-size: 40px;font-family: 'Poppins', sans-serif;">
          Questify
        </h1>
        <div class="d-flex justify-center font-weight-regular align-center">
          Powered by Inventive Media OJT
        </div>
      </div>
    </div>
  </v-footer>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>
