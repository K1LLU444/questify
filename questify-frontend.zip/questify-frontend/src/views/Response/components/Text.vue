<template>
  <div class="rounded-lg">
    <h1 class="mb-10 text-center">{{ question.text }}</h1>
    <v-text-field :model-value="currentAnswer[0] || ''" variant="solo" class="text-field" flat single-line rows="15" @change="select" no-resize density="comfortable" hide-details label="Text"></v-text-field>
  </div>
</template>
<script setup lang="ts">
import useRespondent from '@/composables/useRespondent';
import { useRespondentStore } from '@/store/respondent';
import { storeToRefs } from 'pinia';
const {question} = storeToRefs(useRespondentStore())
const {selectAnswer, clearAnswer, currentAnswer} = useRespondent()
const select = (e: any) => {
  if(Object.keys(question).length > 0){
    //@ts-ignore
    clearAnswer(question.value.id)

    if(!e.target.value){
      return;
    }else{
      //@ts-ignore
      selectAnswer(question.value.id, e.target.value)
    }
  }
}
</script>
<style scoped>
.text-field{
  font-size: 50px !important;;
}
</style>
