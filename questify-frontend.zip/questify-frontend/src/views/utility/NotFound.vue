<template>
  <v-app>
    <v-main class="d-flex flex-column text-white align-center justify-center" style="background: #57375D">
      <h1 style="font-size: 250px;">404</h1>
      <h1>NOT FOUND PAGE <v-icon>mdi-emoticon-sad-outline</v-icon></h1>

    </v-main>
  </v-app>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>
