<template>
  <v-list-item class="rounded-lg bg-white pa-2" @click="$router.push({name: 'response.question', params: {question_id: index + 1}})">
    <template #append>
      <v-icon :color="color">{{ icon }}</v-icon>
    </template>

    <v-card-title class="text-subtitle-2">{{index + 1}}. {{
      //@ts-ignore
      question?.group_name || question.text }}</v-card-title>
  </v-list-item>
</template>

<script setup lang="ts">
import { Question } from '@/store/questionnaire';
import { useRespondentStore } from '@/store/respondent';
import { storeToRefs } from 'pinia';
import { computed } from 'vue';
const {response, questionnaire} = storeToRefs(useRespondentStore())
const question_response = response.value.question_responses.find(item => item.question_id == props.question.id)
const props = defineProps<{question: Question, index: number}>()
const isPending = computed(() => {
  //@ts-ignore
  if(props.question.group_name){
    //@ts-ignore
    return props.question.questions.every((item: any) => {
      const exists = response.value.question_responses.find(innerItem => innerItem.question_id == item.id)
      if(!exists){
        return false
      }

      return exists.answer_keys.length < 1
    })
  }

  //@ts-ignore
  return question_response.answer_keys.length < 1
})
//@ts-ignore
const icon = question_response?.marked ? 'mdi-lightbulb' : isPending.value ? 'mdi-reload' : 'mdi-check'
//@ts-ignore
const color = question_response?.marked ? 'warning' : isPending.value? 'grey' : 'success'
const currentIndex = computed(() => questionnaire.value.questions.findIndex(item => item.id == question_response?.question_id))

</script>

<style scoped>

</style>
